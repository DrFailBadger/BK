﻿$client = "British Broadcasting Corporation"
#$client = "Aviva"


$MainFolder = "G:\2.0 Projects\BBC"

$FolderPath = "$MainFolder\Input"
$OutPutFolder = "$MainFolder\Output"
$DocumentTemplateFolder = "C:\Users\a583418\OneDrive - Atos\Powershell Projects\50.0 - Auto Uplift to Win 10\Project-V2\BBC-Templates"
$companyname = "BBC"
$Companyusername = "BBC User"

Function Utility-MSIDataBase-ApplyUAMStandards {
param(

    [parameter(Mandatory=$true)]
    [ValidateScript({(Test-Path $_) -and ([IO.FileInfo]$_).Extension -eq ".MSI" })]
    [ValidateNotNullOrEmpty()]
    [String]$MSIPath,

    [parameter(Mandatory=$false,
    ParameterSetName="OpenDatabase")]
    [ValidateScript({(Test-Path $_) -and ([IO.FileInfo]$_).Extension -eq ".MST" })]
    [ValidateNotNullOrEmpty()]
    [String]$MSTPath

)
    #This Requires a $CurrentPackage value to be populated for information

	$file = [IO.FileInfo]$MSIPath
	$tmpMSI = $file.FullName + ".tmp"
						
	if (!(Test-Path -Path $tmpMSI)){ Copy-Item -Path $MSIPath -Destination $tmpMSI}
    
    if(!([string]::IsNullOrEmpty($MSTPath))){

	$file1 = [IO.FileInfo]$MSTPath
	$tmpMST = $file1.FullName + ".tmp"
	if (!(Test-Path -Path $tmpMST)){ Copy-Item -Path $MSTPath -Destination $tmpMST
    del $MSTPath
    }
    }

	$transformWithChanges = $file.DirectoryName + "\" + $NewBrickName + ".MST"
    $filecount = 0
	while ([System.IO.File]::Exists($transformWithChanges)) {
		$filecount++
		$transformWithChanges = $file.DirectoryName + "\" + $NewBrickName + "_" + $filecount + ".MST"
	}

					



        try { [IO.File]::OpenWrite($MSIPath).close()
        $Inuse = $false
        }
        catch {
        $Inuse = $True
                }
        While($Inuse -eq $true -and $responce -ne "Cancel Process."){
        $responce = Utility-MessageBox -FormHeader "MSI Locked" -Message "The MSI you have selected seems to be in use.`nDo you have the file open in Orca or Installshield?`nPlease close the MSI to continue." -ButtonOne "MSI Closed." -ButtonTwo "Cancel Process."
        try { [IO.File]::OpenWrite($MSIPath).close()
        $Inuse = $false
        }
        catch {
        $Inuse = $True
        $script:Stop = $true
                }
        }
        
        if ($Inuse -eq $False){


        if(!([string]::IsNullOrEmpty($MSTPath))){

        Try{
        $Script:WindowsInstaller = New-Object -ComObject WindowsInstaller.Installer
        $database2 = $Script:WindowsInstaller.GetType().InvokeMember("OpenDatabase", "InvokeMethod", $null, $Script:WindowsInstaller, @($tmpMSI, 1))    
	    $database2.GetType().InvokeMember("ApplyTransform", [System.Reflection.BindingFlags]::InvokeMethod, $null, $database2, ($tmpMST, 1))
	    }Catch{Write-Error -Message "DataBase Could not be Opened"}
                               
        }else{
        Try{
        $Script:WindowsInstaller = New-Object -ComObject WindowsInstaller.Installer
        $database2 = $Script:WindowsInstaller.GetType().InvokeMember("OpenDatabase", "InvokeMethod", $null, $Script:WindowsInstaller, @($tmpMSI, 1))   

        }Catch{Write-Error -Message "DataBase Could not be Opened"}
        }
        }                 

	$MSIPathOpenDatabaseModeReadOnly = 0
	$MSIPathOpenDatabaseModeTransact = 1
	$MSIPathTransformErrorNone = 0
	$MSIPathTransformValidationNone = 0
			
	$database = $Script:WindowsInstaller.GetType().InvokeMember("OpenDatabase", "InvokeMethod", $null, $Script:WindowsInstaller, ($MSIPath, $MSIPathOpenDatabaseModeReadOnly)) 
 
	#use the TablePersist method to see if the CustomAction table exists
	$tableExists =  $database2.GetType().InvokeMember("TablePersistent","GetProperty",$Null,$database2,"CustomAction")	

	#If table does not exist
	if ([int]$tableExists -ne 1) {
		#Create CustomAction table
		$query = "CREATE TABLE `CustomAction` ( `Action` CHAR(72) NOT NULL, `Type` SHORT NOT NULL, `Source` CHAR(64), `Target` CHAR(255), `ExtendedType` LONG PRIMARY KEY `Action`)"
		$View = $database2.GetType().InvokeMember("OpenView","InvokeMethod",$Null,$database2,($query))
		$View.GetType().InvokeMember("Execute", "InvokeMethod", $Null, $View, $Null)		
		$View.GetType().InvokeMember("Close", "InvokeMethod", $Null, $View, $Null)
		[System.Runtime.Interopservices.Marshal]::ReleaseComObject($View) | Out-Null
		#Create _Validation table entries
		$query = "INSERT INTO ``_Validation`` (``Table``,``Column``,``Nullable``,``MinValue``,``MaxValue``,``Description``) VALUES ('CustomAction','Type','N',1,32767,'The numeric custom action type, consisting of source location, code type, entry, option flags.')"
		$View = $database2.GetType().InvokeMember("OpenView","InvokeMethod",$Null,$database2,($query))
		try {$View.GetType().InvokeMember("Execute", "InvokeMethod", $Null, $View, $Null)} catch {}
		$View.GetType().InvokeMember("Close", "InvokeMethod", $Null, $View, $Null)
		[System.Runtime.Interopservices.Marshal]::ReleaseComObject($View) | Out-Null
		$query = "INSERT INTO ``_Validation`` (``Table``,``Column``,``Nullable``,``Category``,``Description``) VALUES ('CustomAction','Action','N','Identifier','Primary key, name of action, normally appears in sequence table unless private use.')"
		$View = $database2.GetType().InvokeMember("OpenView","InvokeMethod",$Null,$database2,($query))
		try {$View.GetType().InvokeMember("Execute", "InvokeMethod", $Null, $View, $Null)} catch {}
		$View.GetType().InvokeMember("Close", "InvokeMethod", $Null, $View, $Null)
		[System.Runtime.Interopservices.Marshal]::ReleaseComObject($View) | Out-Null
		$query = "INSERT INTO ``_Validation`` (``Table``,``Column``,``Nullable``,``Category``,``Description``) VALUES ('CustomAction','Source','Y','CustomSource','The table reference of the source of the code.')"
		$View = $database2.GetType().InvokeMember("OpenView","InvokeMethod",$Null,$database2,($query))
		try {$View.GetType().InvokeMember("Execute", "InvokeMethod", $Null, $View, $Null)} catch {}
		$View.GetType().InvokeMember("Close", "InvokeMethod", $Null, $View, $Null)
		[System.Runtime.Interopservices.Marshal]::ReleaseComObject($View) | Out-Null
		$query = "INSERT INTO ``_Validation`` (``Table``,``Column``,``Nullable``,``Category``,``Description``) VALUES ('CustomAction','Target','Y','Formatted','Excecution parameter, depends on the type of custom action')"
		$View = $database2.GetType().InvokeMember("OpenView","InvokeMethod",$Null,$database2,($query))
		try {$View.GetType().InvokeMember("Execute", "InvokeMethod", $Null, $View, $Null)} catch {}
		$View.GetType().InvokeMember("Close", "InvokeMethod", $Null, $View, $Null)
		[System.Runtime.Interopservices.Marshal]::ReleaseComObject($View) | Out-Null
		$query = "INSERT INTO ``_Validation`` (``Table``,``Column``,``Nullable``,``MinValue``,``MaxValue``,``Description``) VALUES ('CustomAction','ExtendedType','Y',0,2147483647,'The numeric custom action type info flags.')"
		$View = $database2.GetType().InvokeMember("OpenView","InvokeMethod",$Null,$database2,($query))
		try {$View.GetType().InvokeMember("Execute", "InvokeMethod", $Null, $View, $Null)} catch {}
		$View.GetType().InvokeMember("Close", "InvokeMethod", $Null, $View, $Null)
		[System.Runtime.Interopservices.Marshal]::ReleaseComObject($View) | Out-Null
	}
			
	#use the TablePersist method to see if the Binary table exists
	$tableExists =  $database2.GetType().InvokeMember("TablePersistent","GetProperty",$Null,$database2,"Binary")	

	#If table does not exist
	if ([int]$tableExists -ne 1) {
		#Create Binary table
		$query = "CREATE TABLE `Binary` ( `Name` CHAR(72) NOT NULL, `Data` OBJECT NOT NULL PRIMARY KEY `Name`)"
		$View = $database2.GetType().InvokeMember("OpenView","InvokeMethod",$Null,$database2,($query))
		$View.GetType().InvokeMember("Execute", "InvokeMethod", $Null, $View, $Null)		
		$View.GetType().InvokeMember("Close", "InvokeMethod", $Null, $View, $Null)
		[System.Runtime.Interopservices.Marshal]::ReleaseComObject($View) | Out-Null
		#Create _Validation table entries
		$query = "INSERT INTO ``_Validation`` (``Table``,``Column``,``Nullable``,``Category``,``Description``) VALUES ('Binary','Name','N','Identifier','Unique key identifying the binary data.')"
		$View = $database2.GetType().InvokeMember("OpenView","InvokeMethod",$Null,$database2,($query))
		try {$View.GetType().InvokeMember("Execute", "InvokeMethod", $Null, $View, $Null)} catch {}
		$View.GetType().InvokeMember("Close", "InvokeMethod", $Null, $View, $Null)
		[System.Runtime.Interopservices.Marshal]::ReleaseComObject($View) | Out-Null
		$query = "INSERT INTO ``_Validation`` (``Table``,``Column``,``Nullable``,``Category``,``Description``) VALUES ('Binary','Data','N','Binary','The unformatted binary data.')"
		$View = $database2.GetType().InvokeMember("OpenView","InvokeMethod",$Null,$database2,($query))
		try {$View.GetType().InvokeMember("Execute", "InvokeMethod", $Null, $View, $Null)} catch {}
		$View.GetType().InvokeMember("Close", "InvokeMethod", $Null, $View, $Null)
		[System.Runtime.Interopservices.Marshal]::ReleaseComObject($View) | Out-Null
	}
			
	$query = "INSERT INTO Property (Property,Value) VALUES ('ALLUSERS',1)"
	$View = $database2.GetType().InvokeMember("OpenView","InvokeMethod",$Null,$database2,($query))
	try {$View.GetType().InvokeMember("Execute", "InvokeMethod", $Null, $View, $Null)} catch {}
	$View.GetType().InvokeMember("Close", "InvokeMethod", $Null, $View, $Null)
	[System.Runtime.Interopservices.Marshal]::ReleaseComObject($View) | Out-Null
	$query = "UPDATE `Property` SET `Value` = 1 WHERE `Property` = 'ALLUSERS'"
	$View = $database2.GetType().InvokeMember("OpenView","InvokeMethod",$Null,$database2,($query))
	try {$View.GetType().InvokeMember("Execute", "InvokeMethod", $Null, $View, $Null)} catch {}
	$View.GetType().InvokeMember("Close", "InvokeMethod", $Null, $View, $Null)
	[System.Runtime.Interopservices.Marshal]::ReleaseComObject($View) | Out-Null

	$query = "INSERT INTO `Property` (`Property`,`Value`) VALUES ('ARPNOMODIFY',1)"
	$View = $database2.GetType().InvokeMember("OpenView","InvokeMethod",$Null,$database2,($query))
	try {$View.GetType().InvokeMember("Execute", "InvokeMethod", $Null, $View, $Null)} catch {}
	$View.GetType().InvokeMember("Close", "InvokeMethod", $Null, $View, $Null)
	[System.Runtime.Interopservices.Marshal]::ReleaseComObject($View) | Out-Null
	$query = "UPDATE `Property` SET `Value` = 1 WHERE `Property` = 'ARPNOMODIFY'"
	$View = $database2.GetType().InvokeMember("OpenView","InvokeMethod",$Null,$database2,($query))
	try {$View.GetType().InvokeMember("Execute", "InvokeMethod", $Null, $View, $Null)} catch {}
	$View.GetType().InvokeMember("Close", "InvokeMethod", $Null, $View, $Null)
	[System.Runtime.Interopservices.Marshal]::ReleaseComObject($View) | Out-Null

##Added
	$query = "INSERT INTO `Property` (`Property`,`Value`) VALUES ('ARPCOMMENTS','')"
	$View = $database2.GetType().InvokeMember("OpenView","InvokeMethod",$Null,$database2,($query))
	try {$View.GetType().InvokeMember("Execute", "InvokeMethod", $Null, $View, $Null)} catch {}
	$View.GetType().InvokeMember("Close", "InvokeMethod", $Null, $View, $Null)
	[System.Runtime.Interopservices.Marshal]::ReleaseComObject($View) | Out-Null
	$query = "UPDATE `Property` SET `Value` = '' WHERE `Property` = 'ARPCOMMENTS'"
	$View = $database2.GetType().InvokeMember("OpenView","InvokeMethod",$Null,$database2,($query))
	try {$View.GetType().InvokeMember("Execute", "InvokeMethod", $Null, $View, $Null)} catch {}
	$View.GetType().InvokeMember("Close", "InvokeMethod", $Null, $View, $Null)
	[System.Runtime.Interopservices.Marshal]::ReleaseComObject($View) | Out-Null
##			
	$query = "INSERT INTO `Property` (`Property`,`Value`) VALUES ('ARPNOREMOVE',1)"
	$View = $database2.GetType().InvokeMember("OpenView","InvokeMethod",$Null,$database2,($query))
	try {$View.GetType().InvokeMember("Execute", "InvokeMethod", $Null, $View, $Null)} catch {}
	$View.GetType().InvokeMember("Close", "InvokeMethod", $Null, $View, $Null)
	[System.Runtime.Interopservices.Marshal]::ReleaseComObject($View) | Out-Null
	$query = "UPDATE `Property` SET `Value` = 1 WHERE `Property` = 'ARPNOREMOVE'"
	$View = $database2.GetType().InvokeMember("OpenView","InvokeMethod",$Null,$database2,($query))
	try {$View.GetType().InvokeMember("Execute", "InvokeMethod", $Null, $View, $Null)} catch {}
	$View.GetType().InvokeMember("Close", "InvokeMethod", $Null, $View, $Null)
	[System.Runtime.Interopservices.Marshal]::ReleaseComObject($View) | Out-Null
	
	$query = "INSERT INTO `Property` (`Property`,`Value`) VALUES ('ARPNOREPAIR',1)"
	$View = $database2.GetType().InvokeMember("OpenView","InvokeMethod",$Null,$database2,($query))
	try {$View.GetType().InvokeMember("Execute", "InvokeMethod", $Null, $View, $Null)} catch {}
	$View.GetType().InvokeMember("Close", "InvokeMethod", $Null, $View, $Null)
	[System.Runtime.Interopservices.Marshal]::ReleaseComObject($View) | Out-Null
	$query = "UPDATE `Property` SET `Value` = 1 WHERE `Property` = 'ARPNOREPAIR'"
	$View = $database2.GetType().InvokeMember("OpenView","InvokeMethod",$Null,$database2,($query))
	try {$View.GetType().InvokeMember("Execute", "InvokeMethod", $Null, $View, $Null)} catch {}
	$View.GetType().InvokeMember("Close", "InvokeMethod", $Null, $View, $Null)
	[System.Runtime.Interopservices.Marshal]::ReleaseComObject($View) | Out-Null
			

	    $query = "INSERT INTO `Property` (`Property`,`Value`) VALUES ('COMPANYNAME','" + $companyname + "')"
	    $View = $database2.GetType().InvokeMember("OpenView","InvokeMethod",$Null,$database2,($query))
	    try {$View.GetType().InvokeMember("Execute", "InvokeMethod", $Null, $View, $Null)} catch {}
	    $View.GetType().InvokeMember("Close", "InvokeMethod", $Null, $View, $Null)
	    [System.Runtime.Interopservices.Marshal]::ReleaseComObject($View) | Out-Null
	    $query = "UPDATE `Property` SET `Value` = '" + $companyname + "' WHERE `Property` = 'COMPANYNAME'"
	    $View = $database2.GetType().InvokeMember("OpenView","InvokeMethod",$Null,$database2,($query))
	    try {$View.GetType().InvokeMember("Execute", "InvokeMethod", $Null, $View, $Null)} catch {}
	    $View.GetType().InvokeMember("Close", "InvokeMethod", $Null, $View, $Null)
	    [System.Runtime.Interopservices.Marshal]::ReleaseComObject($View) | Out-Null
		
	    $query = "INSERT INTO `Property` (`Property`,`Value`) VALUES ('USERNAME','" + $Companyusername + "')"
	    $View = $database2.GetType().InvokeMember("OpenView","InvokeMethod",$Null,$database2,($query))
	    try {$View.GetType().InvokeMember("Execute", "InvokeMethod", $Null, $View, $Null)} catch {}
	    $View.GetType().InvokeMember("Close", "InvokeMethod", $Null, $View, $Null)
	    [System.Runtime.Interopservices.Marshal]::ReleaseComObject($View) | Out-Null
	    $query = "UPDATE `Property` SET `Value` = '" + $Companyusername + "' WHERE `Property` = 'USERNAME'"
	    $View = $database2.GetType().InvokeMember("OpenView","InvokeMethod",$Null,$database2,($query))
	    try {$View.GetType().InvokeMember("Execute", "InvokeMethod", $Null, $View, $Null)} catch {}
	    $View.GetType().InvokeMember("Close", "InvokeMethod", $Null, $View, $Null)
	    [System.Runtime.Interopservices.Marshal]::ReleaseComObject($View) | Out-Null
	
		
	$query = "INSERT INTO `Property` (`Property`,`Value`) VALUES ('REBOOT','ReallySuppress')"
	$View = $database2.GetType().InvokeMember("OpenView","InvokeMethod",$Null,$database2,($query))
	try {$View.GetType().InvokeMember("Execute", "InvokeMethod", $Null, $View, $Null)} catch {}
	$View.GetType().InvokeMember("Close", "InvokeMethod", $Null, $View, $Null)
	[System.Runtime.Interopservices.Marshal]::ReleaseComObject($View) | Out-Null
	$query = "UPDATE `Property` SET `Value` = 'ReallySuppress' WHERE `Property` = 'REBOOT'"
	$View = $database2.GetType().InvokeMember("OpenView","InvokeMethod",$Null,$database2,($query))
	try {$View.GetType().InvokeMember("Execute", "InvokeMethod", $Null, $View, $Null)} catch {}
	$View.GetType().InvokeMember("Close", "InvokeMethod", $Null, $View, $Null)
	[System.Runtime.Interopservices.Marshal]::ReleaseComObject($View) | Out-Null
	
	$query = "INSERT INTO `Property` (`Property`,`Value`) VALUES ('ROOTDRIVE','C:\')"
	$View = $database2.GetType().InvokeMember("OpenView","InvokeMethod",$Null,$database2,($query))
	try {$View.GetType().InvokeMember("Execute", "InvokeMethod", $Null, $View, $Null)} catch {}
	$View.GetType().InvokeMember("Close", "InvokeMethod", $Null, $View, $Null)
	[System.Runtime.Interopservices.Marshal]::ReleaseComObject($View) | Out-Null
	$query = "UPDATE `Property` SET `Value` = 'C:\' WHERE `Property` = 'ROOTDRIVE'"
	$View = $database2.GetType().InvokeMember("OpenView","InvokeMethod",$Null,$database2,($query))
	try {$View.GetType().InvokeMember("Execute", "InvokeMethod", $Null, $View, $Null)} catch {}
	$View.GetType().InvokeMember("Close", "InvokeMethod", $Null, $View, $Null)
	[System.Runtime.Interopservices.Marshal]::ReleaseComObject($View) | Out-Null
	
	$query = "INSERT INTO `Property` (`Property`,`Value`) VALUES ('ReinstallModeText','oms')"
	$View = $database2.GetType().InvokeMember("OpenView","InvokeMethod",$Null,$database2,($query))
	try {$View.GetType().InvokeMember("Execute", "InvokeMethod", $Null, $View, $Null)} catch {}
	$View.GetType().InvokeMember("Close", "InvokeMethod", $Null, $View, $Null)
	[System.Runtime.Interopservices.Marshal]::ReleaseComObject($View) | Out-Null
	$query = "UPDATE `Property` SET `Value` = 'oms' WHERE `Property` = 'ReinstallModeText'"
	$View = $database2.GetType().InvokeMember("OpenView","InvokeMethod",$Null,$database2,($query))
	try {$View.GetType().InvokeMember("Execute", "InvokeMethod", $Null, $View, $Null)} catch {}
	$View.GetType().InvokeMember("Close", "InvokeMethod", $Null, $View, $Null)
	[System.Runtime.Interopservices.Marshal]::ReleaseComObject($View) | Out-Null
			
	# Possibly no harm in setting these no matter what the OS
	$query = "INSERT INTO `Property` (`Property`,`Value`) VALUES ('MSIDISABLERMRESTART',0)"
	$View = $database2.GetType().InvokeMember("OpenView","InvokeMethod",$Null,$database2,($query))
	try {$View.GetType().InvokeMember("Execute", "InvokeMethod", $Null, $View, $Null)} catch {}
	$View.GetType().InvokeMember("Close", "InvokeMethod", $Null, $View, $Null)
	[System.Runtime.Interopservices.Marshal]::ReleaseComObject($View) | Out-Null
	$query = "UPDATE `Property` SET `Value` = 0 WHERE `Property` = 'MSIDISABLERMRESTART'"
	$View = $database2.GetType().InvokeMember("OpenView","InvokeMethod",$Null,$database2,($query))
	try {$View.GetType().InvokeMember("Execute", "InvokeMethod", $Null, $View, $Null)} catch {}
	$View.GetType().InvokeMember("Close", "InvokeMethod", $Null, $View, $Null)
	[System.Runtime.Interopservices.Marshal]::ReleaseComObject($View) | Out-Null
		
	$query = "INSERT INTO `Property` (`Property`,`Value`) VALUES ('MSIRMSHUTDOWN',2)"
	$View = $database2.GetType().InvokeMember("OpenView","InvokeMethod",$Null,$database2,($query))
	try {$View.GetType().InvokeMember("Execute", "InvokeMethod", $Null, $View, $Null)} catch {}
	$View.GetType().InvokeMember("Close", "InvokeMethod", $Null, $View, $Null)
	[System.Runtime.Interopservices.Marshal]::ReleaseComObject($View) | Out-Null
	$query = "UPDATE `Property` SET `Value` = 2 WHERE `Property` = 'MSIRMSHUTDOWN'"
	$View = $database2.GetType().InvokeMember("OpenView","InvokeMethod",$Null,$database2,($query))
	try {$View.GetType().InvokeMember("Execute", "InvokeMethod", $Null, $View, $Null)} catch {}
	$View.GetType().InvokeMember("Close", "InvokeMethod", $Null, $View, $Null)
	[System.Runtime.Interopservices.Marshal]::ReleaseComObject($View) | Out-Null
		
	$query = "INSERT INTO `Property` (`Property`,`Value`) VALUES ('MSIRESTARTMANAGERCONTROL','0')"
	$View = $database2.GetType().InvokeMember("OpenView","InvokeMethod",$Null,$database2,($query))
	try {$View.GetType().InvokeMember("Execute", "InvokeMethod", $Null, $View, $Null)} catch {}
	$View.GetType().InvokeMember("Close", "InvokeMethod", $Null, $View, $Null)
	[System.Runtime.Interopservices.Marshal]::ReleaseComObject($View) | Out-Null
	$query = "UPDATE `Property` SET `Value` = '0' WHERE `Property` = 'MSIRESTARTMANAGERCONTROL'"
	$View = $database2.GetType().InvokeMember("OpenView","InvokeMethod",$Null,$database2,($query))
	try {$View.GetType().InvokeMember("Execute", "InvokeMethod", $Null, $View, $Null)} catch {}
	$View.GetType().InvokeMember("Close", "InvokeMethod", $Null, $View, $Null)
	[System.Runtime.Interopservices.Marshal]::ReleaseComObject($View) | Out-Null
			
	$query = "DELETE FROM `Property` WHERE `Property` = 'ARPHELPLINK'"
	$View = $database2.GetType().InvokeMember("OpenView","InvokeMethod",$Null,$database2,($query))
	try {$View.GetType().InvokeMember("Execute", "InvokeMethod", $Null, $View, $Null)} catch {}
	$View.GetType().InvokeMember("Close", "InvokeMethod", $Null, $View, $Null)
	[System.Runtime.Interopservices.Marshal]::ReleaseComObject($View) | Out-Null
			
	$query = "DELETE FROM `Property` WHERE `Property` = 'ARPHELPTELEPHONE'"
	$View = $database2.GetType().InvokeMember("OpenView","InvokeMethod",$Null,$database2,($query))
	try {$View.GetType().InvokeMember("Execute", "InvokeMethod", $Null, $View, $Null)} catch {}
	$View.GetType().InvokeMember("Close", "InvokeMethod", $Null, $View, $Null)
	[System.Runtime.Interopservices.Marshal]::ReleaseComObject($View) | Out-Null

	$query = "DELETE FROM `Property` WHERE `Property` = 'ARPREADME'"
	$View = $database2.GetType().InvokeMember("OpenView","InvokeMethod",$Null,$database2,($query))
	try {$View.GetType().InvokeMember("Execute", "InvokeMethod", $Null, $View, $Null)} catch {}
	$View.GetType().InvokeMember("Close", "InvokeMethod", $Null, $View, $Null)
	[System.Runtime.Interopservices.Marshal]::ReleaseComObject($View) | Out-Null
			
	$query = "DELETE FROM `Property` WHERE `Property` = 'ARPURLINFOABOUT'"
	$View = $database2.GetType().InvokeMember("OpenView","InvokeMethod",$Null,$database2,($query))
	try {$View.GetType().InvokeMember("Execute", "InvokeMethod", $Null, $View, $Null)} catch {}
	$View.GetType().InvokeMember("Close", "InvokeMethod", $Null, $View, $Null)
	[System.Runtime.Interopservices.Marshal]::ReleaseComObject($View) | Out-Null
			
	$query = "DELETE FROM `Property` WHERE `Property` = 'ARPURLUPDATEINFO'"
	$View = $database2.GetType().InvokeMember("OpenView","InvokeMethod",$Null,$database2,($query))
	try {$View.GetType().InvokeMember("Execute", "InvokeMethod", $Null, $View, $Null)} catch {}
	$View.GetType().InvokeMember("Close", "InvokeMethod", $Null, $View, $Null)
	[System.Runtime.Interopservices.Marshal]::ReleaseComObject($View) | Out-Null
			
	#########################################################
		
	$query = "DELETE FROM `Property` WHERE `Property` = 'ISCHECKFORPRODUCTUPDATES'"
	$View = $database2.GetType().InvokeMember("OpenView","InvokeMethod",$Null,$database2,($query))
	try {$View.GetType().InvokeMember("Execute", "InvokeMethod", $Null, $View, $Null)} catch {}
	$View.GetType().InvokeMember("Close", "InvokeMethod", $Null, $View, $Null)
	[System.Runtime.Interopservices.Marshal]::ReleaseComObject($View) | Out-Null
		
	$view = $database.GetType().InvokeMember("OpenView", "InvokeMethod", $null, $database, "SELECT `Value` FROM `Property` WHERE `Property` = 'ProductName'")  
	$view.GetType().InvokeMember("Execute", "InvokeMethod", $null, $view, $null)  
	$record = $view.GetType().InvokeMember("Fetch", "InvokeMethod", $null, $view, $null)  
	$ProductName = $record.GetType().InvokeMember("StringData", "GetProperty", $null, $record, 1)
	$View.GetType().InvokeMember("Close", "InvokeMethod", $Null, $View, $Null)
	[System.Runtime.Interopservices.Marshal]::ReleaseComObject($View) | Out-Null
			
	$view = $database.GetType().InvokeMember("OpenView", "InvokeMethod", $null, $database, "SELECT `Value` FROM `Property` WHERE `Property` = 'ProductVersion'")  
	$view.GetType().InvokeMember("Execute", "InvokeMethod", $null, $view, $null)  
	$record = $view.GetType().InvokeMember("Fetch", "InvokeMethod", $null, $view, $null)  
	$ProductVersion = $record.GetType().InvokeMember("StringData", "GetProperty", $null, $record, 1)
	$View.GetType().InvokeMember("Close", "InvokeMethod", $Null, $View, $Null)
	[System.Runtime.Interopservices.Marshal]::ReleaseComObject($View) | Out-Null
			
	$view = $database.GetType().InvokeMember("OpenView", "InvokeMethod", $null, $database, "SELECT `Value` FROM `Property` WHERE `Property` = 'ProductCode'")  
	$view.GetType().InvokeMember("Execute", "InvokeMethod", $null, $view, $null)  
	$record = $view.GetType().InvokeMember("Fetch", "InvokeMethod", $null, $view, $null)  
	$Script:ProductCode = $record.GetType().InvokeMember("StringData", "GetProperty", $null, $record, 1)
	$View.GetType().InvokeMember("Close", "InvokeMethod", $Null, $View, $Null)
	[System.Runtime.Interopservices.Marshal]::ReleaseComObject($View) | Out-Null
				
	$query = "UPDATE `Property` SET `Value` = '" + $ProductName + " R01" + "' WHERE `Property` = 'ProductName'" # Use vendors existing ProductName but add <Release> to end

	$View = $database2.GetType().InvokeMember("OpenView","InvokeMethod",$Null,$database2,($query))
	try {$View.GetType().InvokeMember("Execute", "InvokeMethod", $Null, $View, $Null)} catch {}
	$View.GetType().InvokeMember("Close", "InvokeMethod", $Null, $View, $Null)
	[System.Runtime.Interopservices.Marshal]::ReleaseComObject($View) | Out-Null
			
	$query = "SELECT `Sequence` FROM `InstallExecuteSequence` WHERE `Action` = 'InstallInitialize'"
	$View = $database2.GetType().InvokeMember("OpenView","InvokeMethod",$Null,$database2,($query))
	$view.GetType().InvokeMember("Execute", "InvokeMethod", $null, $view, $null)  
	$record = $view.GetType().InvokeMember("Fetch", "InvokeMethod", $null, $view, $null)  
	[int] $InstallExecuteSeq = $record.GetType().InvokeMember("StringData", "GetProperty", $null, $record, 1)
	$View.GetType().InvokeMember("Close", "InvokeMethod", $Null, $View, $Null)
	[System.Runtime.Interopservices.Marshal]::ReleaseComObject($View) | Out-Null
			
	$query = "SELECT `Sequence` FROM `InstallExecuteSequence` WHERE `Action` = 'InstallFinalize'"
	$View = $database2.GetType().InvokeMember("OpenView","InvokeMethod",$Null,$database2,($query))
	$view.GetType().InvokeMember("Execute", "InvokeMethod", $null, $view, $null)  
	$record = $view.GetType().InvokeMember("Fetch", "InvokeMethod", $null, $view, $null)  
	[int] $InstallFinalizeSeq = $record.GetType().InvokeMember("StringData", "GetProperty", $null, $record, 1)
	$View.GetType().InvokeMember("Close", "InvokeMethod", $Null, $View, $Null)
	[System.Runtime.Interopservices.Marshal]::ReleaseComObject($View) | Out-Null

	$query = "SELECT `Sequence` FROM `InstallExecuteSequence` WHERE `Action` = 'CostInitialize'"
	$View = $database2.GetType().InvokeMember("OpenView","InvokeMethod",$Null,$database2,($query))
	$view.GetType().InvokeMember("Execute", "InvokeMethod", $null, $view, $null)  
	$record = $view.GetType().InvokeMember("Fetch", "InvokeMethod", $null, $view, $null)  
	[int] $CostInitializeSeq = $record.GetType().InvokeMember("StringData", "GetProperty", $null, $record, 1)
	$View.GetType().InvokeMember("Close", "InvokeMethod", $Null, $View, $Null)
	[System.Runtime.Interopservices.Marshal]::ReleaseComObject($View) | Out-Null
			
	$query = "SELECT `Sequence` FROM `InstallExecuteSequence` WHERE `Action` = 'FileCost'"
	$View = $database2.GetType().InvokeMember("OpenView","InvokeMethod",$Null,$database2,($query))
	$view.GetType().InvokeMember("Execute", "InvokeMethod", $null, $view, $null)  
	$record = $view.GetType().InvokeMember("Fetch", "InvokeMethod", $null, $view, $null)  
	[int] $FileCostSeq = $record.GetType().InvokeMember("StringData", "GetProperty", $null, $record, 1)
	$View.GetType().InvokeMember("Close", "InvokeMethod", $Null, $View, $Null)
	[System.Runtime.Interopservices.Marshal]::ReleaseComObject($View) | Out-Null
			
	$query = "SELECT `Sequence` FROM `InstallExecuteSequence` WHERE `Action` = 'ResolveSource'"
	$View = $database2.GetType().InvokeMember("OpenView","InvokeMethod",$Null,$database2,($query))
	$view.GetType().InvokeMember("Execute", "InvokeMethod", $null, $view, $null)  
	$record = $view.GetType().InvokeMember("Fetch", "InvokeMethod", $null, $view, $null)  
	$View.GetType().InvokeMember("Close", "InvokeMethod", $Null, $View, $Null)
	[System.Runtime.Interopservices.Marshal]::ReleaseComObject($View) | Out-Null
	if ($record -eq $null) {
				
		$seqfree = $false
		$seqno = $CostInitializeSeq
		while ($seqfree -eq $false) {
			$seqno++
			$query = 'SELECT `Sequence` FROM `InstallExecuteSequence` WHERE `Sequence` = ' + $seqno
			$View = $database2.GetType().InvokeMember("OpenView","InvokeMethod",$Null,$database2,($query))
			$view.GetType().InvokeMember("Execute", "InvokeMethod", $null, $view, $null)  
			$record = $view.GetType().InvokeMember("Fetch", "InvokeMethod", $null, $view, $null)
			if ($record -eq $null) {$seqfree = $true}
			$View.GetType().InvokeMember("Close", "InvokeMethod", $Null, $View, $Null)
			[System.Runtime.Interopservices.Marshal]::ReleaseComObject($View) | Out-Null
		}
				
		$query = "INSERT INTO `InstallExecuteSequence` (`Action`,`Condition`,`Sequence`) VALUES ('ResolveSource','NOT REMOVE~=""ALL""'," + $seqno + ")"
		#$query = "INSERT INTO `InstallExecuteSequence` (`Action`,`Condition`,`Sequence`) VALUES ('ResolveSource','NOT REMOVE~=""ALL""'," + ($CostInitializeSeq+1) + ")"
		$View = $database2.GetType().InvokeMember("OpenView","InvokeMethod",$Null,$database2,($query))
		try {$View.GetType().InvokeMember("Execute", "InvokeMethod", $Null, $View, $Null)} catch {}
		$View.GetType().InvokeMember("Close", "InvokeMethod", $Null, $View, $Null)
		[System.Runtime.Interopservices.Marshal]::ReleaseComObject($View) | Out-Null
	}
			
	$seqfree = $false
	$seqno = $FileCostSeq
	while ($seqfree -eq $false) {
		$seqno--
		$query = 'SELECT `Sequence` FROM `InstallExecuteSequence` WHERE `Sequence` = ' + $seqno
		$View = $database2.GetType().InvokeMember("OpenView","InvokeMethod",$Null,$database2,($query))
		$view.GetType().InvokeMember("Execute", "InvokeMethod", $null, $view, $null)  
		$record = $view.GetType().InvokeMember("Fetch", "InvokeMethod", $null, $view, $null)
		if ($record -eq $null) {$seqfree = $true}
		$View.GetType().InvokeMember("Close", "InvokeMethod", $Null, $View, $Null)
		[System.Runtime.Interopservices.Marshal]::ReleaseComObject($View) | Out-Null
	}
			
	$query = "INSERT INTO `InstallExecuteSequence` (`Action`,`Condition`,`Sequence`) VALUES ('SETPROPERTY_SETPERMISSIONS','NOT REMOVE~=""ALL""'," + $seqno + ")"
	#$query = "INSERT INTO `InstallExecuteSequence` (`Action`,`Condition`,`Sequence`) VALUES ('SETPROPERTY_SETPERMISSIONS','NOT REMOVE~=""ALL""'," + ($FileCostSeq-1) + ")"
	$View = $database2.GetType().InvokeMember("OpenView","InvokeMethod",$Null,$database2,($query))
	try {$View.GetType().InvokeMember("Execute", "InvokeMethod", $Null, $View, $Null)} catch {}
	$View.GetType().InvokeMember("Close", "InvokeMethod", $Null, $View, $Null)
	[System.Runtime.Interopservices.Marshal]::ReleaseComObject($View) | Out-Null

	$seqfree = $false
	$seqno = $FileCostSeq
	while ($seqfree -eq $false) {
		$seqno--
		$query = 'SELECT `Sequence` FROM `InstallExecuteSequence` WHERE `Sequence` = ' + $seqno
		$View = $database2.GetType().InvokeMember("OpenView","InvokeMethod",$Null,$database2,($query))
		$view.GetType().InvokeMember("Execute", "InvokeMethod", $null, $view, $null)  
		$record = $view.GetType().InvokeMember("Fetch", "InvokeMethod", $null, $view, $null)
		if ($record -eq $null) {$seqfree = $true}
		$View.GetType().InvokeMember("Close", "InvokeMethod", $Null, $View, $Null)
		[System.Runtime.Interopservices.Marshal]::ReleaseComObject($View) | Out-Null
	}

	$query = "INSERT INTO `InstallExecuteSequence` (`Action`,`Condition`,`Sequence`) VALUES ('SETPROPERTY_COPYSECURITYINF','NOT REMOVE~=""ALL""'," + $seqno + ")"
	#$query = "INSERT INTO `InstallExecuteSequence` (`Action`,`Condition`,`Sequence`) VALUES ('SETPROPERTY_COPYSECURITYINF','NOT REMOVE~=""ALL""'," + ($FileCostSeq-2) + ")"
	$View = $database2.GetType().InvokeMember("OpenView","InvokeMethod",$Null,$database2,($query))
	try {$View.GetType().InvokeMember("Execute", "InvokeMethod", $Null, $View, $Null)} catch {}
	$View.GetType().InvokeMember("Close", "InvokeMethod", $Null, $View, $Null)
	[System.Runtime.Interopservices.Marshal]::ReleaseComObject($View) | Out-Null

	$seqfree = $false
	$seqno = $InstallFinalizeSeq
	while ($seqfree -eq $false) {
		$seqno--
		$query = 'SELECT `Sequence` FROM `InstallExecuteSequence` WHERE `Sequence` = ' + $seqno
		$View = $database2.GetType().InvokeMember("OpenView","InvokeMethod",$Null,$database2,($query))
		$view.GetType().InvokeMember("Execute", "InvokeMethod", $null, $view, $null)  
		$record = $view.GetType().InvokeMember("Fetch", "InvokeMethod", $null, $view, $null)
		if ($record -eq $null) {$seqfree = $true}
		$View.GetType().InvokeMember("Close", "InvokeMethod", $Null, $View, $Null)
		[System.Runtime.Interopservices.Marshal]::ReleaseComObject($View) | Out-Null
	}

	$query = "INSERT INTO `InstallExecuteSequence` (`Action`,`Condition`,`Sequence`) VALUES ('SETPERMISSIONS','NOT REMOVE~=""ALL""'," + $seqno + ")"
	#$query = "INSERT INTO `InstallExecuteSequence` (`Action`,`Condition`,`Sequence`) VALUES ('SETPERMISSIONS','NOT REMOVE~=""ALL""'," + ($InstallFinalizeSeq-1) + ")"
	$View = $database2.GetType().InvokeMember("OpenView","InvokeMethod",$Null,$database2,($query))
	try {$View.GetType().InvokeMember("Execute", "InvokeMethod", $Null, $View, $Null)} catch {}
	$View.GetType().InvokeMember("Close", "InvokeMethod", $Null, $View, $Null)
	[System.Runtime.Interopservices.Marshal]::ReleaseComObject($View) | Out-Null

	$seqfree = $false
	$seqno = $InstallFinalizeSeq
	while ($seqfree -eq $false) {
		$seqno--
		$query = 'SELECT `Sequence` FROM `InstallExecuteSequence` WHERE `Sequence` = ' + $seqno
		$View = $database2.GetType().InvokeMember("OpenView","InvokeMethod",$Null,$database2,($query))
		$view.GetType().InvokeMember("Execute", "InvokeMethod", $null, $view, $null)  
		$record = $view.GetType().InvokeMember("Fetch", "InvokeMethod", $null, $view, $null)
		if ($record -eq $null) {$seqfree = $true}
		$View.GetType().InvokeMember("Close", "InvokeMethod", $Null, $View, $Null)
		[System.Runtime.Interopservices.Marshal]::ReleaseComObject($View) | Out-Null
	}
			
	$query = "INSERT INTO `InstallExecuteSequence` (`Action`,`Condition`,`Sequence`) VALUES ('COPYSECURITYINF','NOT REMOVE~=""ALL""'," + $seqno + ")"
	#$query = "INSERT INTO `InstallExecuteSequence` (`Action`,`Condition`,`Sequence`) VALUES ('COPYSECURITYINF','NOT REMOVE~=""ALL""'," + ($InstallFinalizeSeq-2) + ")"
	$View = $database2.GetType().InvokeMember("OpenView","InvokeMethod",$Null,$database2,($query))
	try {$View.GetType().InvokeMember("Execute", "InvokeMethod", $Null, $View, $Null)} catch {}
	$View.GetType().InvokeMember("Close", "InvokeMethod", $Null, $View, $Null)
	[System.Runtime.Interopservices.Marshal]::ReleaseComObject($View) | Out-Null

	$query = "INSERT INTO `Binary` (`Name`,`Data`) Values(?,?)"
	$View = $database2.GetType().InvokeMember("OpenView","InvokeMethod",$Null,$database2,($query))
	$binaryrecord = $Script:WindowsInstaller.GetType().InvokeMember("CreateRecord", "InvokeMethod", $null, $Script:WindowsInstaller, 2)  
	$binaryrecord.GetType().InvokeMember("StringData", "SetProperty", $null, $binaryrecord, @(1, "Callcopysecurityinf"))
	$aa = ${env:ProgramFiles(x86)} + "\Atos\UAM Tools\DocGen\Support\COPYSECURITY.TXT"
	$binaryrecord.GetType().InvokeMember("SetStream","InvokeMethod", $null, $binaryrecord, @(2, $aa))
	try {$View.GetType().InvokeMember("Execute", "InvokeMethod", $Null, $View, $binaryrecord)} catch {}
	$View.GetType().InvokeMember("Close", "InvokeMethod", $Null, $View, $Null)
	[System.Runtime.Interopservices.Marshal]::ReleaseComObject($View) | Out-Null

 	$query = "INSERT INTO `CustomAction` (`Action`,`Type`,`Source`) VALUES ('COPYSECURITYINF',1094,'Callcopysecurityinf')"
 	$View = $database2.GetType().InvokeMember("OpenView","InvokeMethod",$Null,$database2,($query))
	try {$View.GetType().InvokeMember("Execute", "InvokeMethod", $Null, $View, $Null)} catch {}
	$View.GetType().InvokeMember("Close", "InvokeMethod", $Null, $View, $Null)
	[System.Runtime.Interopservices.Marshal]::ReleaseComObject($View) | Out-Null

	$query = "INSERT INTO `Binary` (`Name`,`Data`) Values(?,?)"
	$View = $database2.GetType().InvokeMember("OpenView","InvokeMethod",$Null,$database2,($query))
	$binaryrecord = $Script:WindowsInstaller.GetType().InvokeMember("CreateRecord", "InvokeMethod", $null, $Script:WindowsInstaller, 2)  
	$binaryrecord.GetType().InvokeMember("StringData", "SetProperty", $null, $binaryrecord, @(1, "Callsetpermissions"))
	$aa = ${env:ProgramFiles(x86)} + "\Atos\UAM Tools\DocGen\Support\SETPERMISSIONS.TXT"
	$binaryrecord.GetType().InvokeMember("SetStream","InvokeMethod", $null, $binaryrecord, @(2, $aa))
	try {$View.GetType().InvokeMember("Execute", "InvokeMethod", $Null, $View, $binaryrecord)} catch {}
	$View.GetType().InvokeMember("Close", "InvokeMethod", $Null, $View, $Null)
	[System.Runtime.Interopservices.Marshal]::ReleaseComObject($View) | Out-Null

 	$query = "INSERT INTO `CustomAction` (`Action`,`Type`,`Source`) VALUES ('SETPERMISSIONS',3142,'Callsetpermissions')"
 	$View = $database2.GetType().InvokeMember("OpenView","InvokeMethod",$Null,$database2,($query))
	try {$View.GetType().InvokeMember("Execute", "InvokeMethod", $Null, $View, $Null)} catch {}
	$View.GetType().InvokeMember("Close", "InvokeMethod", $Null, $View, $Null)
	[System.Runtime.Interopservices.Marshal]::ReleaseComObject($View) | Out-Null
			
	$query = "INSERT INTO `CustomAction` (`Action`,`Type`,`Source`,`Target`) VALUES ('SETPROPERTY_COPYSECURITYINF',51,'COPYSECURITYINF','[SourceDir]')"
	$View = $database2.GetType().InvokeMember("OpenView","InvokeMethod",$Null,$database2,($query))
	try {$View.GetType().InvokeMember("Execute", "InvokeMethod", $Null, $View, $Null)} catch {}
	$View.GetType().InvokeMember("Close", "InvokeMethod", $Null, $View, $Null)
	[System.Runtime.Interopservices.Marshal]::ReleaseComObject($View) | Out-Null

	$query = "INSERT INTO `CustomAction` (`Action`,`Type`,`Source`,`Target`) VALUES ('SETPROPERTY_SETPERMISSIONS',51,'SETPERMISSIONS','[ProductName];;[SourceDir]')"
	$View = $database2.GetType().InvokeMember("OpenView","InvokeMethod",$Null,$database2,($query))
	try {$View.GetType().InvokeMember("Execute", "InvokeMethod", $Null, $View, $Null)} catch {}
	$View.GetType().InvokeMember("Close", "InvokeMethod", $Null, $View, $Null)
	[System.Runtime.Interopservices.Marshal]::ReleaseComObject($View) | Out-Null
			
	#Commit the changes to our backup database
	$database2.GetType().InvokeMember("Commit", "InvokeMethod", $Null, $database2, $Null)

	#Generate a transform (the difference between our original MSI and our Backup MSI) 
	$transformSuccess = $database2.GetType().InvokeMember("GenerateTransform", "InvokeMethod", $Null, $database2, @($database, $transformWithChanges))  

	#Create a Summary Information Stream for the MST
	$transformSummarySuccess = $database2.GetType().InvokeMember("CreateTransformSummaryInfo", "InvokeMethod", $Null, $database2, @($database, $transformWithChanges, $MSIPathTransformErrorNone, $MSIPathTransformValidationNone))  

	#Read Summary Information Stream Installer Object
	$SumInfo = $Script:WindowsInstaller.GetType().InvokeMember("SummaryInformation", "GetProperty", $Null, $Script:WindowsInstaller, @($transformWithChanges, 6))

	$notationcheck = [System.Text.RegularExpressions.Regex]::Match($CurrentPackage.ApplicationName, "\d+\.\d+(\.\d+)?(\.\d+)?")
	if ($notationcheck.length -eq 0) {
		$SISTitle = $CurrentPackage.ApplicationName + " " + $ProductVersion + " R01"
	}
	else {
		$SISTitle = $CurrentPackage.ApplicationName + " R01" 
	}
			
	# 	 'title
	$SumInfo.GetType().InvokeMember("Property", [System.Reflection.BindingFlags]::SetProperty, $null, $SumInfo, (2, $SISTitle))
	# 	 'subject
	$SumInfo.GetType().InvokeMember("Property", [System.Reflection.BindingFlags]::SetProperty, $null, $SumInfo, (3, ""))
	# 	 'author
	$SumInfo.GetType().InvokeMember("Property", [System.Reflection.BindingFlags]::SetProperty, $null, $SumInfo, (4, "Atos User Application Management Team"))
	# 	 'keywords
	$SumInfo.GetType().InvokeMember("Property", [System.Reflection.BindingFlags]::SetProperty, $null, $SumInfo, (5, ""))
	# 	 'comment
	$SumInfo.GetType().InvokeMember("Property", [System.Reflection.BindingFlags]::SetProperty, $null, $SumInfo, (6, "Packaging Guidelines AW v5.0"))
	# 	 'creating app
    $strDescription = "Packaging Archive and Documentation Creator"
	$strVersion = "1.12"
	$createapp = $Description + " " + $Version
	$SumInfo.GetType().InvokeMember("Property", [System.Reflection.BindingFlags]::SetProperty, $null, $SumInfo, (18, $createapp))
			
	#Save the SIS
	$SumInfo.GetType().InvokeMember("Persist", [System.Reflection.BindingFlags]::InvokeMethod, $null, $SumInfo, $null)

 	#Release objects from memory
	[System.Runtime.Interopservices.Marshal]::ReleaseComObject($database) | Out-Null 
	[System.Runtime.Interopservices.Marshal]::ReleaseComObject($database2) | Out-Null
	[System.Runtime.Interopservices.Marshal]::ReleaseComObject($SumInfo) | Out-Null
	[System.Runtime.Interopservices.Marshal]::ReleaseComObject($Script:WindowsInstaller) | Out-Null

    [System.GC]::Collect()
 	#Delete backup database
	If (Test-Path $tmpMSI) {Remove-Item $tmpMSI}

    if(!([string]::IsNullOrEmpty($MSTPath))){
	If (Test-Path $tmpMST) {Remove-Item $tmpMST}
    }

	$Script:NewInstallCommand = 'msiexec /i "' + $(([IO.FileInfo]$MSIPath).Name) + '" TRANSFORMS="' + $NewBrickName + '.MST" /qb+! /l*v "%WINDIR%\temp\' + $NewBrickName + '.log"'
	$Script:NewUninstallCommand= 'msiexec /x ' + $ProductCode + ' /qb! /l*v "%WINDIR%\temp\' + $NewBrickName + '.log"'


}

Function Utility-MessageBox {
   [CmdletBinding(DefaultParameterSetName='DefaultIcon1')]
    Param(  
    
        [Parameter(Mandatory=$True,
                   HelpMessage = "Place Any String Here")]
                   [ValidateScript({$_.length -in 1..50})]
        [String]$FormHeader,
        
        [Parameter(Mandatory=$True,
                   HelpMessage = "Place Any String Here")]
        [String]$Message,

        [Parameter(Mandatory=$False,
                   HelpMessage = "Form Background Colour")]
        [ValidateSet('black','white','red','lime','blue','yellow','fuchsia','aqua','maroon','green','navy','olive','purple','teal','silver','gray')]
        [String]$BackColour = "White",

        [Parameter(Mandatory=$False,
                   HelpMessage = "Form Style")]
        [ValidateSet('None','FixedSingle','Fixed3D','FixedDialog','Sizable','FixedToolWindow','SizableToolWindow')]
        [String]$FormStyle = "FixedSingle",

        [Parameter(Mandatory=$False,
                   HelpMessage = "Text Size")]
        [ValidateScript({$_ -in 1..72})]
        [int]$FontSize = 12,

        [Parameter(Mandatory=$False,
                   HelpMessage = "Text to be displayed as the first button, this will also be the returned value when the button is clicked")]
                   [ValidateScript({$_.length -in 1..30})]
        [String]$ButtonOne = "Accept",

        [Parameter(Mandatory=$False,
                   HelpMessage = "Text to be displayed as the Second button, this will also be the returned value when the button is clicked")]
                   [ValidateScript({$_.length -in 1..30})]
        [String]$ButtonTwo,

        [Parameter(Mandatory=$False,
                   HelpMessage = "Do you want a commant box or not.")]
                   [ValidateSet('Yes','No')]
        [String]$DisplayCommentBox = 'No',
  
        [Parameter(Mandatory = $False, ParameterSetName = 'DefaultIcon1')]
        [ValidateSet('Information','Exclamation','Question','Error','Warning')]
        [String]$DefaultIcon = "Information",

        [Parameter(Mandatory = $False,
                   HelpMessage = "Enter a base 64 ico string or path to .ico file",
                   ParameterSetName="CustomIcon1")]
        [String]$CustomIcon,

        [Parameter(Mandatory = $False,
                   HelpMessage = "Time in minutes before the form closes automatically")]
        [ValidateScript({$_.length -in 0.1..10000})]
        [decimal]$TimeOut_Minutes,

        [Parameter(Mandatory = $False,
                   HelpMessage = "Do you wish to show the time remaining until the form closes automatically on the hearder?")]
        [ValidateSet('Yes','No')]
        [String]$ShowTimeOutRemaining = 'No',

        [Parameter(Mandatory = $False,
                   HelpMessage = "Make this window always on top.")]
        [ValidateSet('True','False')]
        [String]$Topmost = 'False',

        [Parameter(Mandatory = $False,
                   HelpMessage = "Make the comment box input be hidden")]
        [ValidateSet('True','False')]
        [String]$CommentAsPassword = 'False'
    
    
    )

    DynamicParam {
            # Set the dynamic parameters' name
            $TextFont = 'TextFont'
            
            # Create the dictionary 
            $RuntimeParameterDictionary = New-Object System.Management.Automation.RuntimeDefinedParameterDictionary

            # Create the collection of attributes
            $AttributeCollection = New-Object System.Collections.ObjectModel.Collection[System.Attribute]
            
            # Create and set the parameters' attributes
            $ParameterAttribute = New-Object System.Management.Automation.ParameterAttribute
            $ParameterAttribute.Mandatory = $False
            $ParameterAttribute.Position = 1

            # Add the attributes to the attributes collection
            $AttributeCollection.Add($ParameterAttribute)

            # Generate and set the ValidateSet 
            [void] [System.Reflection.Assembly]::LoadWithPartialName("System.Drawing")
            $objFonts = New-Object System.Drawing.Text.InstalledFontCollection
            $arrSet = $objFonts.Families.name|foreach{$_ = "$_".Replace(" ","")
            $_}

            $ValidateSetAttribute = New-Object System.Management.Automation.ValidateSetAttribute($arrSet)

            # Add the ValidateSet to the attributes collection
            $AttributeCollection.Add($ValidateSetAttribute)
            #$AttributeCollection.Validvalues

            # Create and return the dynamic parameter
            $RuntimeParameter = New-Object System.Management.Automation.RuntimeDefinedParameter($TextFont, [string],$AttributeCollection)
            $RuntimeParameter.Value = "$Script:MasterFontStyle"
            $RuntimeParameterDictionary.Add($TextFont, $RuntimeParameter)
            return $RuntimeParameterDictionary
    }

BEGIN {
        [void] [System.Reflection.Assembly]::LoadWithPartialName("System.Drawing")
        $objFonts = New-Object System.Drawing.Text.InstalledFontCollection
        $Fonts = $objFonts.Families.name
        $TextFont = $PsBoundParameters[$TextFont]
        $TextFont = $Fonts |Where-Object {"$_".Replace(" ","") -eq $TextFont}
        IF($TextFont.count -ne 1){$TextFont = "$Script:MasterFontStyle"}
        
        $FormTimeoutDate = (Get-date).AddMinutes($TimeOut_Minutes)

    }


PROCESS {



function OnApplicationLoad {
	#Note: This function is not called in Projects
	#Note: This function runs before the form is created
	#Note: To get the script directory in the Packager use: Split-Path $hostinvocation.MyCommand.path
	#Note: To get the console output in the Packager (Windows Mode) use: $ConsoleOutput (Type: System.Collections.ArrayList)
	#Important: Form controls cannot be accessed in this function
	#TODO: Add snapins and custom code to validate the application load
	
	return $true #return true for success or false for failure
}

function OnApplicationExit {
	#Note: This function is not called in Projects
	#Note: This function runs after the form is closed
	#TODO: Add custom code to clean up and unload snapins when the application exits
	
	$script:ExitCode = 0 #Set the exit code for the Packager
}

#----------------------------------------------
# Generated Form Function
#----------------------------------------------
function Call-MessageBox_pff {

	#----------------------------------------------
	#region Import the Assemblies
	#----------------------------------------------
	[void][reflection.assembly]::Load("mscorlib, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089")
	[void][reflection.assembly]::Load("System, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089")
	[void][reflection.assembly]::Load("System.Windows.Forms, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089")
	[void][reflection.assembly]::Load("System.Data, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089")
	[void][reflection.assembly]::Load("System.Drawing, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a")
	[void][reflection.assembly]::Load("System.Xml, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089")
	[void][reflection.assembly]::Load("System.DirectoryServices, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a")
	[void][reflection.assembly]::Load("System.Core, Version=3.5.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089")
	[void][reflection.assembly]::Load("System.ServiceProcess, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a")
	#endregion Import Assemblies

	#----------------------------------------------
	#region Generated Form Objects
	#----------------------------------------------
	[System.Windows.Forms.Application]::EnableVisualStyles()
	$FormPrompt = New-Object 'System.Windows.Forms.Form'
	$panelLabels = New-Object 'System.Windows.Forms.Panel'
	$labelPleaseEnterInformati = New-Object 'System.Windows.Forms.Label'
	$panelComment = New-Object 'System.Windows.Forms.Panel'
	$textbox1 = New-Object 'System.Windows.Forms.TextBox'
	$PanelButtons = New-Object 'System.Windows.Forms.Panel'
	$buttonYes = New-Object 'System.Windows.Forms.Button'
	$buttonNo = New-Object 'System.Windows.Forms.Button'
	$InitialFormWindowState = New-Object 'System.Windows.Forms.FormWindowState'
	$timer1 = New-Object 'System.Windows.Forms.Timer'
	#endregion Generated Form Objects

	#----------------------------------------------
	# User Generated Script
	#----------------------------------------------
	
	
	$FormPrompt_Load={
		
	$Script:MessageReturn = $null
    $Script:MessageCommentBox = $null
	$font = New-Object System.Drawing.Font("$TextFont", $FontSize, [System.Drawing.FontStyle]'Regular')
	$size = [System.Windows.Forms.TextRenderer]::MeasureText("$($labelPleaseEnterInformati.Text)", $font)
	IF($size.Width -lt 400){
	$FormPrompt.Width = 400		
	} elseif($size.Width -gt 1500){
	$FormPrompt.Width = 1500	
	}else{
	$FormPrompt.Width = $size.Width
		}
	
	if($DisplayCommentBox -eq "Yes"){


	if($size.height + 180 -gt 1500){
	$FormPrompt.height = 1500	
	}else{
	$FormPrompt.height = $size.height + 180
		}
	}else{

	if($size.height + 100 -gt 1500){
	$FormPrompt.height = 1500	
	}else{
	$FormPrompt.height = $size.height + 100
		}



    }
		#TODO: Initialize Form Controls here
	$timer1.Enabled = $true
    $script:123MessagePassword = ""

	}
	
	$PanelButtons_Resize={

    If($ButtonTwo -ne ""){
		#TODO: Place custom script here
		#$position $panel1.Width
		$buttonNo.width = ($PanelButtons.Width / 2 ) - 11
		$buttonNo.Location.X = ($PanelButtons.Width / 2 ) + 5
		$buttonYes.Width = ($PanelButtons.Width / 2 ) - 11
		$buttonYes.Location.X = ($PanelButtons.Location.X) + 5
		#$panel1
     }else{
        $buttonYes.Width = ($PanelButtons.Width ) - 11
        }
	}

    $timer1_Tick={
    IF($TimeOut_Minutes -ne ""){
    $FormTimeout = (Get-Date -Date $FormTimeoutDate).TimeOfDay.TotalSeconds - (Get-date).TimeOfDay.TotalSeconds
    $ts2 =  [timespan]::fromseconds($FormTimeout)
    If($ShowTimeOutRemaining -eq 'Yes'){
    $FormPrompt.Text = "$FormHeader |Time Remaining: $($ts2.minutes):$("{0:D2}" -f $ts2.seconds)"
    }
    IF($FormTimeout -lt 0){
    $Script:MessageReturn = "TimeOut"
    $FormPrompt.Close()}
    }
	#TODO: Place custom script here
	
    }

    $buttonYes_Click={
    if($CommentAsPassword -eq $true){
    $Script:MessageCommentBox = $script:123MessagePassword
    }else{
    $Script:MessageCommentBox = $textbox1.text
    }
    $Script:MessageReturn = $buttonYes.Text
    $FormPrompt.Close()
	#TODO: Place custom script here
	
    }

    $buttonNo_Click={
    $Script:MessageCommentBox = $textbox1.text
    $Script:MessageReturn = $buttonNo.Text
    $FormPrompt.Close()
	#TODO: Place custom script here
	
    }

    $textbox1_TextChanged={
    #TODO: Place custom script here
	#Event Argument: $_ = [System.ComponentModel.CancelEventArgs]
	#TODO: Place custom script here
    if($CommentAsPassword -eq $true){
	if($textbox1.Text.Length -eq 0){$script:123MessagePassword = ""}
	elseif($textbox1.Text.Length -gt "$script:123MessagePassword".length ){
	$script:123MessagePassword = $script:123MessagePassword + $textbox1.Text.Substring($textbox1.Text.Length - 1)
	$textbox1.Text = "*" * "$script:123MessagePassword".length
	$textbox1.SelectionStart = $textbox1.Text.Length
	}elseif($textbox1.Text.Length -lt "$script:123MessagePassword".length ){
			
	$script:123MessagePassword = $script:123MessagePassword.substring(0,"$script:123MessagePassword".length -("$script:123MessagePassword".length - $textbox1.Text.Length ))
	$textbox1.Text = "*" * "$script:123MessagePassword".length
	$textbox1.SelectionStart = $textbox1.Text.Length
	}
    
    }
    }
	
	# --End User Generated Script--
	#----------------------------------------------
	#region Generated Events
	#----------------------------------------------
	
	$Form_StateCorrection_Load=
	{
		#Correct the initial state of the form to prevent the .Net maximized form issue
		$FormPrompt.WindowState = $InitialFormWindowState
	}
	
	$Form_Cleanup_FormClosed=
	{
		#Remove all event handlers from the controls
		try
		{
			$PanelButtons.remove_Resize($PanelButtons_Resize)
			$FormPrompt.remove_Load($FormPrompt_Load)
			$FormPrompt.remove_Load($Form_StateCorrection_Load)
			$FormPrompt.remove_FormClosed($Form_Cleanup_FormClosed)
			$timer1.remove_Tick($timer1_Tick)
			$buttonYes.remove_Click($buttonYes_Click)
			$buttonNo.remove_Click($buttonNo_Click)
			$textbox1.remove_TextChanged($textbox1_TextChanged)
		}
		catch [Exception]
		{ }
	}
	#endregion Generated Events

	#----------------------------------------------
	#region Generated Form Code
	#----------------------------------------------
	#
	# FormPrompt
	#
	$FormPrompt.Controls.Add($panelLabels)
	$FormPrompt.Controls.Add($panelComment)
	$FormPrompt.Controls.Add($PanelButtons)
	$FormPrompt.BackColor = "$BackColour"
	$FormPrompt.ClientSize = '518, 224'
	$FormPrompt.Font = "$TextFont, 12pt"
    $FormPrompt.FormBorderStyle = "$FormStyle"
    $FormPrompt.TopMost = $Topmost

    if($CustomIcon -ne ""){

        $FormIcon = $CustomIcon

        }else{
        Switch ($DefaultIcon) {

        Information {$FormPrompt.Icon = [System.Drawing.SystemIcons]::Information}
        Exclamation {$FormPrompt.Icon = [System.Drawing.SystemIcons]::Exclamation}
        Question    {$FormPrompt.Icon = [System.Drawing.SystemIcons]::Question   }
        Error       {$FormPrompt.Icon = [System.Drawing.SystemIcons]::Error      }
        Warning     {$FormPrompt.Icon = [System.Drawing.SystemIcons]::Warning    }
        
        }
     
       }

	$FormPrompt.MinimumSize = '400, 100'
	$FormPrompt.Name = "FormPrompt"

	$FormPrompt.Text = $FormHeader
    IF($ShowTimeOutRemaining -eq 'Yes'){
    $FormPrompt.Text = "$FormHeader |Time Remaining: 0"
    }
	$FormPrompt.add_Load($FormPrompt_Load)
	#
	# panelLabels
	#
	$panelLabels.Controls.Add($labelPleaseEnterInformati)
	$panelLabels.AutoSizeMode = 'GrowAndShrink'
	$panelLabels.Dock = 'Fill'
	$panelLabels.Location = '0, 0'
	$panelLabels.Name = "panelLabels"
	$panelLabels.Padding = '5, 5, 5, 5'
	$panelLabels.Size = '518, 108'
	$panelLabels.TabIndex = 4
	#
	# labelPleaseEnterInformati
	#
	$labelPleaseEnterInformati.BorderStyle = 'FixedSingle'
	$labelPleaseEnterInformati.Dock = 'Fill'
	$labelPleaseEnterInformati.Location = '5, 5'
    $labelPleaseEnterInformati.Font = "$TextFont, $FontSize`pt"
	$labelPleaseEnterInformati.Name = "labelPleaseEnterInformati"
	$labelPleaseEnterInformati.Size = '508, 98'
	$labelPleaseEnterInformati.TabIndex = 3
	$labelPleaseEnterInformati.Text = $Message
	$labelPleaseEnterInformati.TextAlign = 'MiddleCenter'
	#
	# panelComment
	#
	$panelComment.Controls.Add($textbox1)
	$panelComment.AutoSizeMode = 'GrowAndShrink'
	$panelComment.Dock = 'Bottom'
	$panelComment.Location = '0, 108'
	$panelComment.Name = "panelComment"
	$panelComment.Size = '518, 76'
	$panelComment.TabIndex = 5
    IF($DisplayCommentBox -eq 'No'){$panelComment.Visible = $False}
	#
	# textbox1
	#
	$textbox1.Anchor = 'Top, Bottom, Left, Right'
	$textbox1.BorderStyle = 'FixedSingle'
	$textbox1.Location = '5, 3'
	$textbox1.Multiline = $True
	$textbox1.Name = "textbox1"
	$textbox1.ScrollBars = 'Vertical'
	$textbox1.Size = '507, 67'
	$textbox1.TabIndex = 0
	$textbox1.add_TextChanged($textbox1_TextChanged)
	#
	# PanelButtons
	#
	$PanelButtons.Controls.Add($buttonYes)
	$PanelButtons.Controls.Add($buttonNo)
	$PanelButtons.AutoSizeMode = 'GrowAndShrink'
	$PanelButtons.Dock = 'Bottom'
	$PanelButtons.Location = '0, 184'
	$PanelButtons.Name = "PanelButtons"
	$PanelButtons.Size = '518, 40'
	$PanelButtons.TabIndex = 2
	$PanelButtons.add_Resize($PanelButtons_Resize)
	#
	# buttonYes
	#
	$buttonYes.AutoSizeMode = 'GrowAndShrink'
	$buttonYes.FlatAppearance.MouseDownBackColor = '128, 255, 128'
	$buttonYes.FlatAppearance.MouseOverBackColor = '192, 255, 192'
	$buttonYes.FlatStyle = 'Flat'
	$buttonYes.Location = '5, 6'
	$buttonYes.Name = "buttonYes"
	$buttonYes.Size = '254, 28'
	$buttonYes.TabIndex = 0
	$buttonYes.Text = "$ButtonOne"
	$buttonYes.UseVisualStyleBackColor = $True
	$buttonYes.add_Click($buttonYes_Click)
	#
	# buttonNo
	#
	$buttonNo.Anchor = 'Top'
	$buttonNo.AutoSizeMode = 'GrowAndShrink'
	$buttonNo.FlatAppearance.MouseDownBackColor = '255, 128, 128'
	$buttonNo.FlatAppearance.MouseOverBackColor = '255, 192, 192'
	$buttonNo.FlatStyle = 'Flat'
	$buttonNo.Location = '264, 6'
	$buttonNo.Name = "buttonNo"
	$buttonNo.Size = '248, 28'
	$buttonNo.TabIndex = 1
	$buttonNo.Text = "$ButtonTwo"
	$buttonNo.UseVisualStyleBackColor = $True
	$buttonNo.add_Click($buttonNo_Click)
    If($ButtonTwo -eq ""){$buttonNo.Visible = $False
    $buttonYes.Size = '518, 28'
    }
    #
	# timer1
	#
	$timer1.add_Tick($timer1_Tick)
	#endregion Generated Form Code

	#----------------------------------------------

	#Save the initial state of the form
	$InitialFormWindowState = $FormPrompt.WindowState
	#Init the OnLoad event to correct the initial state of the form
	$FormPrompt.add_Load($Form_StateCorrection_Load)
	#Clean up the control events
	$FormPrompt.add_FormClosed($Form_Cleanup_FormClosed)
	#Show the Form
	Return $FormPrompt.ShowDialog()


} #End Function

#Call OnApplicationLoad to initialize
if((OnApplicationLoad) -eq $true)
{
	#Call the form
	Call-MessageBox_pff|Out-Null
	#Perform cleanup
	OnApplicationExit
}




}

END {Return $Script:MessageReturn,$Script:MessageCommentBox}

}           #Allows you to pop up a custom message box

function Replace-Word{
Param(
[string]$Document,
$Table
)

    $ReplaceAll = 2
    $FindContinue = 1

    $MatchCase = $False
    $MatchWholeWord = $True 
    $MatchWildcards = $True 
    $MatchSoundsLike = $False 
    $MatchAllWordForms = $False
    $Forward = $True
    $Wrap = $FindContinue
    $Format = $False

    $Word = New-Object -comobject Word.Application
    $Word.Visible = $False
    
    $OpenDoc = $Word.Documents.Open("$Document")
    $Selection = $Word.Selection


 Foreach($row in $Table){ 
 
    $Selection.Find.Execute(
    $($row.From),
    $MatchCase,
    $MatchWholeWord,
    $MatchWildcards,
    $MatchSoundsLike,
    $MatchAllWordForms,
    $Forward,
    $Wrap,
    $Format,
    $($row.To),
    $ReplaceAll
    ) | Out-Null


 Foreach($header in $OpenDoc.sections.Item(1).Headers){
 $header.Range.Find.Execute(
    $($row.From),
    $MatchCase,
    $MatchWholeWord,
    $MatchWildcards,
    $MatchSoundsLike,
    $MatchAllWordForms,
    $Forward,
    $Wrap,
    $Format,
    $($row.To),
    $ReplaceAll
    ) | Out-Null
    }

    }
    
    $OpenDoc.Close()
    $Word.quit()
}

Function Mass-Unencrypt {
   [CmdletBinding(DefaultParameterSetName='DefaultIcon1')]
    Param(  
        [Parameter(Mandatory=$True,
                   HelpMessage = "Place Any Path Here")]
                   [ValidateScript({Test-Path "$_"})]
        [String]$FolderPath,
        [Parameter(Mandatory=$True,
                   HelpMessage = "Place Any Client Name")]
        [String]$Client
        )


$strSharePointSiteURL = "https://uam.ms.myatos.net/"
[void][System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SharePoint.Client")
[void][System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SharePoint.Client.Runtime")
[System.Net.CredentialCache]$credentials = New-Object -TypeName System.Net.CredentialCache
$ctx = New-Object Microsoft.SharePoint.Client.ClientContext($strSharePointSiteURL)
$ctx.Credentials = $credentials.DefaultNetworkCredentials;
$ctx.RequestTimeOut = 5000 * 60 * 10
$web = $ctx.Web
$list = $web.Lists.GetByTitle("Application Tracker")
$camlQuery = New-Object Microsoft.SharePoint.Client.CamlQuery
$camlQuery.ViewXml = "<View>
<Query>
<Where>
<Eq>
<FieldRef Name='Client' />
<Value Type='Text'>$client</Value>
</Eq>
</Where>
</Query>
<RowLimit>1000000</RowLimit>
</View>"
$spListItemCollection = $List.GetItems($camlQuery)
$ctx.Load($spListItemCollection)
$ctx.ExecuteQuery()
$Script:Tracker =@()
foreach ($item in $spListItemCollection){

$Script:Tracker += New-Object PsObject -Property @{
Tracker = "New" 
BrickName = $item['Package_x0020_archive_x0020_name']
UAMID = $item['Title']
ApplicationName = $item['ApplicationName'] 
Client = $item['Client'].LookupValue
EncryptionPassword = $item['EncryptionPassword']
InstallCommand = $item['Install_x0020_command']
UninstallCommand = $item['Uninstall_x0020_command']
Description = $item['Application_x0020_Description']
Vendor = $item['ApplicationVendor0'].LookupValue
Architecture = $item['PackageArchitecture']
Layer = $item['ApplicationLayer']
PackageType = $item['PackageType']
ApplicationVersion = $item['ApplicationVersion']
OldADGroup = $item['Install_x0020_AD_x0020_group']
InstallReboot = $item['Reboot_x0020_after_x0020_install']
UninstallReboot = $item['Reboot_x0020_after_x0020_uninsta']
Remark = $item['Package_x0020_Remark']
}
}

   $list = $web.Lists.GetByTitle("Application Hub (Legacy)")
    $camlQuery = New-Object Microsoft.SharePoint.Client.CamlQuery
    $camlQuery.ViewXml = "<View>
<Query>
    <Where>
            <Eq>
                <FieldRef Name='Client' />
                <Value Type='Text'>$Client</Value>
            </Eq>
    </Where>
</Query>
<RowLimit>10000000</RowLimit>
</View>"

    $spListItemCollection = $List.GetItems($camlQuery)
    $ctx.Load($spListItemCollection)
    $ctx.ExecuteQuery()
    #$Tracker = @()
    foreach ($item in $spListItemCollection){

    $Script:Tracker += New-Object PsObject -Property @{
    Tracker = "Old" 
    UAMID = $item['Title']
    ApplicationName = $item['Application_x0020_Name'] 
    Client = $item['Client']
    EncryptionPassword = $item['Encryption_x0020_password']
    BrickName = $item['Archive_x0020_Name']
    InstallCommand = 'N/A'
    UninstallCommand = 'N/A'
    Description = 'N/A'
    Vendor = $item['Application_x0020_Vendor']
    Architecture = $item['Package_x0020_architecture']
    Layer = $item['Application_x0020_Layer']
    PackageType = $item['Package_x0020_Technology']
    ApplicationVersion = $item['Application_x0020_Version']
    OldADGroup = 'N/A'
    InstallReboot = 'N/A'
    UninstallReboot = 'N/A'
    Remark = 'N/A'
    
    }
    }

$Complete = @()

$Applications = Dir "$FolderPath" -Filter "*-*"|Where {$_.Attributes -eq "Directory" }

Foreach($App in $Applications){

$last = Dir $App.FullName -Filter "*R*-B*"|select -Last 1
$Folders = Dir $last.FullName -Filter "Encrypted*.zip"
$Pass = $true
$Reason = ""

$Brickname = $null
$Brickname = "$($app.Name)-$($last.Name)"


Foreach($Folder in $Folders){
$Brickname = $null
$Brickname = ($Folder.Name).TrimEnd("-Documents.zip").TrimEnd("-Installation.zip").TrimEnd("-Source.zip").Replace("Encrypted-","")
$Returnval = $null
$Returnval = $Script:Tracker |where {$_.BrickName -eq $Brickname}

$7Zip = "${env:ProgramFiles(x86)}\Atos\UAM Tools\Package Release\Support\7za.exe"
$try = ""
foreach($item in $Returnval){
if("$try" -notmatch "Everything is Ok"){
$try = & $7Zip x "$($Folder.FullName)" -o"$(([IO.FileInfo]"$($Folder.FullName)").Directory)"  -p"$($item.EncryptionPassword)" -aoa
}
}
if("$try" -notmatch "Everything is Ok"){
Write-Host "Failed To Unencrypted | A record can't be found that matches $Brickname | Folder $($FolderPath.Name)" -ForegroundColor Red
$Pass = $False
$Reason = "Failed To Unencrypted | A record can't be found that matches $Brickname | Folder $($FolderPath.Name)"
}else{
Write-Host "Successfully Unencrypted | $Brickname | Folder - $($Folder.Name)" -ForegroundColor Green
}
}
$Complete += New-Object PsObject -Property @{
BrickName = $Brickname
Pass = $Pass
Reason = $Reason
Path = $last.FullName
}


}
return $Complete
}

Function Create-SMS {

$InjectText=""
switch ($($CurrentPackage.Layer)) 
	{ 
		Layer1 {$InjectText = "CanRunWhen=UserLoggedOn"}  #UAM dont do Layer 1 packages so no used
		Layer2 {$InjectText = "CanRunWhen=AnyUserStatus`r`nRun=Hidden"} 
		Layer3 {$InjectText = "CanRunWhen=UserLoggedOn"} 
		Layer4 {$InjectText = "CanRunWhen=UserLoggedOn"}  #Manual installations where SCCM pushes down the source
		default {$InjectText = "CanRunWhen=UserLoggedOn"}
	}



"[PDF]
Version=2.0

[Package Definition] 
Name=$($CurrentPackage.ApplicationName)
Version=$($CurrentPackage.ApplicationVersion) R01 B01
Publisher=$($CurrentPackage.Vendor)
Comment=N/A
Language=English
Programs=Install, Uninstall

[Install]
Name=Install
CommandLine=$NewInstallCommand
Comment=$($CurrentPackage.ApplicationName) $($CurrentPackage.ApplicationVersion)
UserInputRequired=False
AdminRightsRequired=True
SupportedClients=Win NT (I386),Win NT (x64)
Win NT (I386) MinVersion1=6.10.0000.0
Win NT (I386) MaxVersion1=6.10.9999.9999
Win NT (x64) MinVersion1=6.10.0000.0
Win NT (x64) MaxVersion1=6.10.9999.9999
AdditionalProgramRequirements=$($CurrentPackage.Layer)
ADGroup=APPL-G-SCCM$($CurrentPackage.Vendor)-$($CurrentPackage.ApplicationName)-$($CurrentPackage.ApplicationVersion)
$InjectText

[Uninstall]
Name=Uninstall
CommandLine=$NewUninstallCommand
Comment=Uninstall $($CurrentPackage.ApplicationName) $($CurrentPackage.ApplicationVersion)
UserInputRequired=False
AdminRightsRequired=True
SupportedClients=Win NT (I386),Win NT (x64)
Win NT (I386) MinVersion1=6.10.0000.0
Win NT (I386) MaxVersion1=6.10.9999.9999
Win NT (x64) MinVersion1=6.10.0000.0
Win NT (x64) MaxVersion1=6.10.9999.9999
AdditionalProgramRequirements=$($CurrentPackage.Layer) 
ADGroup=APPL-G-SCCM$($CurrentPackage.Vendor)-$($CurrentPackage.ApplicationName)-$($CurrentPackage.ApplicationVersion)
$InjectText
"  |Out-File  "$OutPutFolder\$NewShortBrick\R01-B01\Installation\$NewBrickName.sms" -Encoding ascii



}

function Get-IniContent ($filePath)
{
try{
    $ini = @{}
    switch -regex -file $FilePath
    {
        "^\[(.+)\]" # Section
        {
            $section = $matches[1]
            $ini[$section] = @{}
            $CommentCount = 0
        }
        "^(;.*)$" # Comment
        {
            $value = $matches[1]
            $CommentCount = $CommentCount + 1
            $name = "Comment" + $CommentCount
            $ini[$section][$name] = $value
        } 
        "(.+?)\s*=(.*)" # Key
        {
            $name,$value = $matches[1..2]
            $ini[$section][$name] = $value
        }
    }
    return $ini
    }Catch{Write-Host "SMS Failed to Index, Please check : $filePath"}
}

$ExtractionOutcome = Mass-Unencrypt -FolderPath $FolderPath -Client $client

$Final =@()
Foreach($Application in $ExtractionOutcome){
if($Application.Pass -eq $True){

$ItemFound = @()
$ItemFound += ($Script:Tracker|where {$_.BrickName -eq $Application.BrickName}|select -Last 1)|Select-Object *,@{Name='Path';Expression={"$($Application.Path)"}},@{Name='Pass';Expression={"$($Application.Pass)"}}
if($ItemFound.count -eq 1){
$Final += ($Script:Tracker|where {$_.BrickName -eq $Application.BrickName}|select -Last 1)|Select-Object *,@{Name='Path';Expression={"$($Application.Path)"}},@{Name='Pass';Expression={"$($Application.Pass)"}}
}else{

$SMS = Dir "$($Application.Path)\Installation" -Filter "*.SMS" 
if($sms.count -eq 1){

$SMSFile = Get-IniContent -filePath $SMS.FullName

$Final += New-Object PsObject -Property @{
Tracker = "None" 
BrickName = $Application.BrickName
UAMID = "N/A"
ApplicationName = $SMSFile.'Package Definition'.'Name'.TrimEnd(" ")
Client = $client
EncryptionPassword = "N/A"
InstallCommand = "N/A"
UninstallCommand = "N/A"
Description = "N/A"
Vendor = $SMSFile.'Package Definition'.'Publisher'
Architecture = "$(if($SMS.BaseName -match "-x64-"){"X64 (64 Bit)" }else{"X86 (32 Bit)"})"
Layer = $SMSFile.'Install'.'AdditionalProgramRequirements'
PackageType = "$(if($SMSFile.'Install'.'CommandLine' -match 'cscript'){'Scripted'}elseif($SMSFile.'Install'.'CommandLine' -match 'MSIEXEC'){'MSI'}elseif(($SMS.BaseName -Match "-AV-") -or ($SMS.BaseName -Match "-AV5-")){"App-V" }else{"N/A"})"
ApplicationVersion = ($SMSFile.'Package Definition'.'Version').Split(" ")[0]
OldADGroup = 'N/A'
InstallReboot = 'N/A'
UninstallReboot = 'N/A'
Remark = "N/A"
Path = $Application.Path
Pass = $Application.Pass
}

}

else{

$Final += New-Object PsObject -Property @{
Tracker = "None" 
BrickName = $Application.BrickName
UAMID = "N/A"
ApplicationName = $(((Split-path (Split-Path $Application.Path) -Leaf).Split("-"))[0]) 
Client = $client
EncryptionPassword = "N/A"
InstallCommand = "N/A"
UninstallCommand = "N/A"
Description = "N/A"
Vendor = "N/A"
Architecture = "N/A"
Layer = "N/A"
PackageType = "N/A"
ApplicationVersion = $(((Split-path (Split-Path $Application.Path) -Leaf).Split("-"))[1]) 
OldADGroup = 'N/A'
InstallReboot = 'N/A'
UninstallReboot = 'N/A'
Remark = 'N/A'
Path = $Application.Path
Pass = $Application.Pass
}
}


}

}
}

$Final|Export-Csv "$MainFolder\Final.csv"
$Continue = Read-Host -Prompt "Please review the information in '$MainFolder\Final.csv' all information must be correct in order to get a good conversion. Save once completed. and Enter 'Y'"

if($Continue -eq 'Y'){
$Final = @()
$Final += Import-Csv "$MainFolder\Final.csv"
$AppComments =@()
Foreach($CurrentPackage in $final){


#Calculate New BrickName
$NewShortBrick = "$($CurrentPackage.ApplicationName -replace ' ','')-$($CurrentPackage.ApplicationVersion.Replace('.',''))-$(if($CurrentPackage.PackageType -match 'App-V'){'AV-'})$(if(!([string]::IsNullOrEmpty($CurrentPackage.Remark))){"$($CurrentPackage.Remark -replace ' ','')-"})$(if($CurrentPackage.Architecture -ne 'X86 (32 Bit)'){'x64-'})100"
$NewBrickName = "$NewShortBrick-R01-B01"

#Make New Directory
MD "$OutPutFolder\$NewShortBrick\R01-B01\Documents" -Force
MD "$OutPutFolder\$NewShortBrick\R01-B01\Installation" -Force
MD "$OutPutFolder\$NewShortBrick\R01-B01\Source" -Force
"$($CurrentPackage.BrickName)" > "$OutPutFolder\$NewShortBrick\R01-B01\Source\Original-Package.txt"
#

##Fix Docs##
$Table = @()
$Table += New-Object PsObject -Property @{
From = "$($CurrentPackage.BrickName)"
To = $NewBrickName
}
$Table += New-Object PsObject -Property @{
From = "$(Split-path $CurrentPackage.Path -Leaf)"
To = "R01-B01"
}
$Table += New-Object PsObject -Property @{
From = "$((Split-path $CurrentPackage.Path -Leaf) -split '-' -join ' ')"
To = "R01 B01"
}
$Table += New-Object PsObject -Property @{
From = "SCCM 2012"
To = "SCCM 1610"
}
$Table += New-Object PsObject -Property @{
From = "Windows 7 32 Bit"
To = "Windows 10 64 Bit"
}
$Table += New-Object PsObject -Property @{
From = "Windows 7 64 Bit"
To = "Windows 10 64 Bit"
}
$Table += New-Object PsObject -Property @{
From = "([0-9]{1,2})[/]([0-9]{1,2})[/]([0-9]{4})"
To = "$(Get-Date -Format 'dd-MM-yyyy')"
}
$Table += New-Object PsObject -Property @{
From = "([0-9]{1,2})[-]([0-9]{1,2})[-]([0-9]{4})"
To = "$(Get-Date -Format 'dd-MM-yyyy')"
}
if((Dir "$($CurrentPackage.Path)\Installation" -Recurse "*.MST")){
Foreach($MST in (Dir "$($CurrentPackage.Path)\Installation" -Recurse "*.MST")){
$Table += New-Object PsObject -Property @{
From = "$($MST.Name)"
To = "$NewBrickName.MST"
}
}
}

foreach($file in (Dir "$($CurrentPackage.Path)\Documents")){

if($file.BaseName -match "Application Discovery" ){
if((Get-date -Date $file.LastWriteTime).Year -ge "2015"){
Copy $file.FullName -Destination "$OutPutFolder\$NewShortBrick\R01-B01\Documents\Application Discovery $NewBrickName.docx"
Replace-Word -Document "$OutPutFolder\$NewShortBrick\R01-B01\Documents\Application Discovery $NewBrickName.docx" -Table $Table
}Else{
$AppComments += "Warning : Documentation: $NewBrickname : Discovery Doc did not uplift as older than 2015 - New Doc has been generated with what information is available. Please Check and uplift comments."
Write-host "Warning : Documentation: $NewBrickname : Discovery Doc did not uplift as older than 2015 - New Doc has been generated with what information is available. Please Check and uplift comments." -ForegroundColor Yellow

}
}

if($file.BaseName -match "Package Build"){
if((Get-date -Date $file.LastWriteTime).Year -ge "2015"){
Copy $file.FullName -Destination "$OutPutFolder\$NewShortBrick\R01-B01\Documents\Package Build $NewBrickName.docx"
Replace-Word -Document "$OutPutFolder\$NewShortBrick\R01-B01\Documents\Package Build $NewBrickName.docx" -Table $Table
}Else{
$AppComments += "Warning : Documentation: $NewBrickname : Packaging Doc did not uplift as older than 2015 - New Doc has been generated with what information is available. Please Check and uplift comments."
Write-host "Warning : Documentation: $NewBrickname : Packaging Doc did not uplift as older than 2015 - New Doc has been generated with what information is available. Please Check and uplift comments." -ForegroundColor Yellow
}
}


}

####Packaging##

Copy "$($CurrentPackage.Path)\Installation\*" -Destination "$OutPutFolder\$NewShortBrick\R01-B01\Installation" -Recurse -Force

if($CurrentPackage.PackageType -match "MSI"){
$MSIs = @()
$MSIs += Dir "$OutPutFolder\$NewShortBrick\R01-B01\Installation" -Filter "*.MSI"
$MSTs = @()
$MSTs += Dir "$OutPutFolder\$NewShortBrick\R01-B01\Installation" -Filter "*.MST" 
$CABFiles =@()
$CABFiles += Dir "$OutPutFolder\$NewShortBrick\R01-B01\Installation" -Filter "*.Cab" 

if(($MSIs.count -eq 1) -and ($MSTs.Count -eq 0) ){
Utility-MSIDataBase-ApplyUAMStandards -MSIPath $MSIs.FullName
}elseif(($MSIs.count -eq 1) -and ($MSTs.Count -eq 1)){
Utility-MSIDataBase-ApplyUAMStandards -MSIPath $MSIs.FullName -MSTPath $MSTs.FullName
}
Write-host "Info : Packaging: $NewBrickname : Creating New Package, Transform uplifted, SMS and Commandlines will be re-made." -ForegroundColor Green

if($CABFiles.Count -gt 0 ){
$AppComments += "Warning : Packaging: $NewBrickname : Package Contains CAB Files, Please check internal cab names are correct."
Write-Host "Warning : Packaging: $NewBrickname : Package Contains CAB Files, Please check internal cab names are correct." -ForegroundColor Yellow
}

$NewInstallCommand |Out-File "$OutPutFolder\$NewShortBrick\R01-B01\Installation\Install.cmd" -Encoding ascii
$NewUninstallCommand |Out-File "$OutPutFolder\$NewShortBrick\R01-B01\Installation\Uninstall.cmd" -Encoding ascii

Del "$OutPutFolder\$NewShortBrick\R01-B01\Installation\*.sms"
Create-SMS


}


elseif($CurrentPackage.PackageType -match "APP-V"){
$NewInstallCommand = "None Required Import as APPV"
$NewUninstallCommand = "None Required Import as APPV"
Del "$OutPutFolder\$NewShortBrick\R01-B01\Installation\*.sms"
Create-SMS

$AppComments += "Warning : Packaging: $NewBrickname : Package is App-V This will require conversion to uplift."
Write-host "Warning : Packaging: $NewBrickname : Package is App-V This will require conversion to uplift." -ForegroundColor Yellow

}elseif($CurrentPackage.PackageType -match "Scripted"){


$NewInstallCommand = "cscript INSTALL-$NewBrickName.vbs"
$NewUninstallCommand = "cscript UNINSTALL-$NewBrickName.vbs"

$NewInstallCommand |Out-File "$OutPutFolder\$NewShortBrick\R01-B01\Installation\Install.cmd" -Encoding ascii
$NewUninstallCommand |Out-File "$OutPutFolder\$NewShortBrick\R01-B01\Installation\Uninstall.cmd" -Encoding ascii

try{
Rename-Item "$OutPutFolder\$NewShortBrick\R01-B01\Installation\Install-*.VBS" -NewName "INSTALL-$NewBrickName.VBS"
Rename-Item "$OutPutFolder\$NewShortBrick\R01-B01\Installation\UnInstall-*.VBS" -NewName "UNINSTALL-$NewBrickName.VBS"

$VBSInstallContent = Get-Content "$OutPutFolder\$NewShortBrick\R01-B01\Installation\INSTALL-$NewBrickName.VBS"
$VBSUnInstallContent = Get-Content "$OutPutFolder\$NewShortBrick\R01-B01\Installation\UNINSTALL-$NewBrickName.VBS"

$foundSDB = $False
Foreach($line in $VBSInstallContent){
if($line -match "sSDBName=`"$($CurrentPackage.ApplicationName) $($CurrentPackage.ApplicationVersion.Replace('.','')) $(((Split-Path $CurrentPackage.Path -Leaf).Split('-'))[0])`""){
$foundSDB = $True
}
}
if($foundSDB -eq $False){
$AppComments += "Warning : Packaging: $NewBrickname : Install Script does not contain Standard SDB Lines please check and uplift to new format if needed."
Write-host "Warning : Packaging: $NewBrickname : Install Script does not contain Standard SDB Lines please check and uplift to new format if needed." -ForegroundColor Yellow

}

$VBSInstallContent = $VBSInstallContent.Replace("$($CurrentPackage.BrickName)","$NewBrickName").Replace("sSDBName=`"$($CurrentPackage.ApplicationName) $($CurrentPackage.ApplicationVersion) $(((Split-Path $CurrentPackage.Path -Leaf).Split('-'))[0])`"","sSDBName=`"$($CurrentPackage.ApplicationName) $($CurrentPackage.ApplicationVersion) R01`"")
$VBSInstallContent |Out-File "$OutPutFolder\$NewShortBrick\R01-B01\Installation\INSTALL-$NewBrickName.VBS"

$foundSDB = $False
Foreach($line in $VBSUninstallContent){
if($line -eq "sSDBName=`"$($CurrentPackage.ApplicationName) $($CurrentPackage.ApplicationVersion.Replace('.','')) $(((Split-Path $CurrentPackage.Path -Leaf).Split('-'))[0])`""){
$foundSDB = $True
}
}

if($foundSDB -eq $False){
$AppComments += "Warning : Packaging: $NewBrickname : UnInstall Script does not contain Standard SDB Lines please check and uplift to new format if needed."
Write-host "Warning : Packaging: $NewBrickname : UnInstall Script does not contain Standard SDB Lines please check and uplift to new format if needed." -ForegroundColor Yellow

}

$VBSUninstallContent = $VBSUninstallContent.Replace("$($CurrentPackage.BrickName)","$NewBrickName").Replace("sSDBName=`"$($CurrentPackage.ApplicationName) $($CurrentPackage.ApplicationVersion) $(((Split-Path $CurrentPackage.Path -Leaf).Split('-'))[0])`"","sSDBName=`"$($CurrentPackage.ApplicationName) $($CurrentPackage.ApplicationVersion) R01`"")
$VBSUninstallContent |Out-File "$OutPutFolder\$NewShortBrick\R01-B01\installation\Uninstall-$NewBrickName.VBS"


}
Catch{

$AppComments += "Warning : Packaging: $NewBrickname : Package Type is scripted but some scripts could not be found or updated please check"
Write-host "Warning : Packaging: $NewBrickname : Package Type is scripted but some scripts could not be found or updated please check" -ForegroundColor Yellow


}


Del "$OutPutFolder\$NewShortBrick\R01-B01\Installation\*.sms"
Create-SMS

}



}
}


